package co.edu.icesi.repositories;

import org.springframework.data.repository.CrudRepository;

import co.edu.icesi.model.Unitmeasure;

public interface UnitmeasureRepositoryInterface extends CrudRepository<Unitmeasure, String>{

}
