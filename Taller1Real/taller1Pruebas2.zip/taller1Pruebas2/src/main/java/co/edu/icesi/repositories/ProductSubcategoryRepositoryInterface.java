package co.edu.icesi.repositories;

import org.springframework.data.repository.CrudRepository;

import co.edu.icesi.model.Productsubcategory;

public interface ProductSubcategoryRepositoryInterface extends CrudRepository<Productsubcategory, Integer>{
    
}
