package co.edu.icesi.repository;

import org.springframework.data.repository.CrudRepository;

import co.edu.icesi.model.Institution;

public interface InstitutionRepositoryI extends CrudRepository<Institution, Long>{

}
