package co.edu.icesi.repository;

import org.springframework.data.repository.CrudRepository;

import co.edu.icesi.model.Localcondition;

public interface LocalconditionRepositoryI extends CrudRepository<Localcondition, Long>{

}
