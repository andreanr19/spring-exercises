package co.edu.icesi.repository;

import org.springframework.data.repository.CrudRepository;

import co.edu.icesi.model.Epidemstatus;

public interface EpidemstatusRepositoryI extends CrudRepository<Epidemstatus, Long>{

}
