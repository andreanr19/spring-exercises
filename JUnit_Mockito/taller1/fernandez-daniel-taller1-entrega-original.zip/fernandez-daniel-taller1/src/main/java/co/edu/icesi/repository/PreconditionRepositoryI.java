package co.edu.icesi.repository;

import org.springframework.data.repository.CrudRepository;

import co.edu.icesi.model.Precondition;

public interface PreconditionRepositoryI extends CrudRepository<Precondition, Long> {

}
